/*
 * Copyright (c) 2018 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-BSD-5-Clause-Nordic
 */

/** @file
 *  @brief Nordic UART Bridge Service (NUS) sample
 */

#include <zephyr/types.h>
#include <zephyr.h>
#include <uart.h>
#include <stdlib.h>
#include <stdio.h>

#include <device.h>
#include <soc.h>
#include <gpio.h>
#include <drivers/pwm.h>

#include <bluetooth/bluetooth.h>
#include <bluetooth/uuid.h>
#include <bluetooth/gatt.h>
#include <bluetooth/hci.h>

#include <bluetooth/services/nus.h>

#include <dk_buttons_and_leds.h>

#include <stdio.h>
#include "board_functions.h"
#include "adc.h"
#include "ble.h"
#include "vars.c"

#define STACKSIZE               CONFIG_BT_GATT_NUS_THREAD_STACK_SIZE
#define PRIORITY                7

#define DEVICE_NAME             CONFIG_BT_DEVICE_NAME
#define DEVICE_NAME_LEN	        (sizeof(DEVICE_NAME) - 1)



#define KEY_PASSKEY_ACCEPT DK_BTN1_MSK
#define KEY_PASSKEY_REJECT DK_BTN2_MSK

#define UART_BUF_SIZE           CONFIG_BT_GATT_NUS_UART_BUFFER_SIZE


#if defined(DT_ALIAS_PWM_LED0_PWMS_CONTROLLER)
/* get the defines from dt (based on alias 'pwm-led0') */
#define PWM_DRIVER	DT_ALIAS_PWM_LED0_PWMS_CONTROLLER
#define PWM_CHANNEL	11
#else
//#error "Choose supported PWM driver"
#endif

/*
 * 50 is flicker fusion threshold. Modulated light will be perceived
 * as steady by our eyes when blinking rate is at least 50.
 */
#define PERIOD (USEC_PER_SEC / 50U)

/* in micro second */
extern int FADESTEP;

extern int vcc;

extern int led_blink_state;


extern int pulse_width;

static K_SEM_DEFINE(ble_init_ok, 0, 2);

//extern void connected(struct bt_conn*conn, u8_t err);

struct bt_conn_cb conn_callbacks = {
	.connected    = connected,
	.disconnected = disconnected,
#ifdef CONFIG_BT_GATT_NUS_SECURITY_ENABLED
	.security_changed = security_changed,
#endif
};

/*struct bt_conn_auth_cb conn_auth_callbacks = {
	.passkey_display = auth_passkey_display,
	.passkey_confirm = auth_passkey_confirm,
	.cancel = auth_cancel,
	.pairing_confirm = auth_done,
	.pairing_complete = pairing_complete,
	.pairing_failed = pairing_failed
};*/
extern struct bt_conn_auth_cb conn_auth_callbacks;



static u32_t led_pins[] = {DT_ALIAS_LED0_GPIOS_PIN,
			   DT_ALIAS_LED1_GPIOS_PIN,
			   DT_ALIAS_LED2_GPIOS_PIN,
			   DT_ALIAS_LED3_GPIOS_PIN};

/*struct uart_data_t {
	void  *fifo_reserved;
	u8_t    data[UART_BUF_SIZE];
	u16_t   len;
};*/



static K_FIFO_DEFINE(fifo_uart_tx_data);
static K_FIFO_DEFINE(fifo_uart_rx_data);

static K_FIFO_DEFINE(fifo_ble_tx_data);



 

static void uart_cb(struct device *uart)
{
	static struct uart_data_t *rx;

	uart_irq_update(uart);

	if (uart_irq_rx_ready(uart)) {
		int data_length;

		if (!rx) {
			rx = k_malloc(sizeof(*rx));
			if (rx) {
				rx->len = 0;
			} else {
				char dummy;

				printk("Not able to allocate UART receive buffer\n");

				/* Drop one byte to avoid spinning in a
				 * eternal loop.
				 */
				uart_fifo_read(uart, &dummy, 1);

				return;
			}
		}

		data_length = uart_fifo_read(uart, &rx->data[rx->len],
					     UART_BUF_SIZE-rx->len);
		rx->len += data_length;

		if (rx->len > 0) {
			/* Send buffer to bluetooth unit if either buffer size
			 * is reached or the char \n or \r is received, which
			 * ever comes first
			 */
			if ((rx->len == UART_BUF_SIZE) ||
			   (rx->data[rx->len - 1] == '\n') ||
			   (rx->data[rx->len - 1] == '\r')) {
				k_fifo_put(&fifo_uart_rx_data, rx);
				rx = NULL;
			}
		}
	}

	if (uart_irq_tx_ready(uart)) {
		struct uart_data_t *buf =
			k_fifo_get(&fifo_uart_tx_data, K_NO_WAIT);
		u16_t written = 0;

		/* Nothing in the FIFO, nothing to send */
		if (!buf) {
			uart_irq_tx_disable(uart);
			return;
		}

		while (buf->len > written) {
			written += uart_fifo_fill(uart,
						  &buf->data[written],
						  buf->len - written);
		}

		while (!uart_irq_tx_complete(uart)) {
			/* Wait for the last byte to get
			 * shifted out of the module
			 */
		}

		if (k_fifo_is_empty(&fifo_uart_tx_data)) {
			uart_irq_tx_disable(uart);
		}

		k_free(buf);
	}
}

static int init_uart(void)
{
	uart = device_get_binding("UART_0");
	if (!uart) {
		return -ENXIO;
	}

	uart_irq_callback_set(uart, uart_cb);
	uart_irq_rx_enable(uart);

	return 0;
}





void error(void)
{
	int err = -1;

	struct device* led_port = device_get_binding(LED_PORT);
	if (led_port) {
		for (size_t i = 0; i < ARRAY_SIZE(led_pins); i++) {
			err = gpio_pin_configure(led_port, led_pins[i],
						 GPIO_DIR_OUT);
			if (err) {
				break;
			}
		}
	}

	if (!err) {
		for (size_t i = 0; i < ARRAY_SIZE(led_pins); i++) {
			err = gpio_pin_write(led_port, led_pins[i], LED_ON);
			if (err) {
				break;
			}
		}
	}

	while (true) {
		/* Spin for ever */
		k_sleep(1000);
	}
}

static void num_comp_reply(bool accept)
{
        struct bt_conn *auth_conn;
	if (accept) {
		bt_conn_auth_passkey_confirm(auth_conn);
		printk("Numeric Match, conn %p\n", auth_conn);
	} else {
		bt_conn_auth_cancel(auth_conn);
		printk("Numeric Reject, conn %p\n", auth_conn);
	}

	bt_conn_unref(auth_conn);
	auth_conn = NULL;
}

void button_changed(u32_t button_state, u32_t has_changed)
{
	u32_t buttons = button_state & has_changed;
        struct bt_conn *auth_conn;
	if (auth_conn) {
		if (buttons & KEY_PASSKEY_ACCEPT) {
			num_comp_reply(true);
		}

		if (buttons & KEY_PASSKEY_REJECT) {
			num_comp_reply(false);
		}
	}
}

void configure_buttons(void)
{
	int err = dk_buttons_init(button_changed);

	if (err) {
		printk("Cannot init buttons (err: %d)\n", err);
	}
}

static void led_blink_thread(void)
{
	int    blink_status       = 0;
	int    err                = 0;
        struct device *pwm_dev;

        pwm_dev = device_get_binding(PWM_DRIVER);
	if (!pwm_dev) {
		printk("Cannot find %s!\n", PWM_DRIVER);
		return;
	}

	printk("Starting Nordic UART service example\n");

	err = init_uart();
	if (!err) {
		err = bt_enable(bt_ready);
	}

	configure_buttons();

	if (!err) {
		bt_conn_cb_register(&conn_callbacks);

		if (IS_ENABLED(CONFIG_BT_GATT_NUS_SECURITY_ENABLED)) {
			bt_conn_auth_cb_register(&conn_auth_callbacks);
		}

		err = k_sem_take(&ble_init_ok, K_MSEC(100));

		if (!err) {
			printk("Bluetooth initialized\n");
		} else {
			printk("BLE initialization \
				did not complete in time\n");
		}
	}

	if (err) {
		error();
	}

	init_gpio();

	for (;;) {
                if (blink_status)
                {
                  vcc = 5.0f/3.0f*sample_adc();
                }
		set_led_state(RUN_STATUS_LED, (++blink_status) % 2);
                set_led_state(FIVE_V_EN, (blink_status) % 2);

                //pwm_pin_set_usec(pwm_dev, 23,
		//			PERIOD, (blink_status % 2) * 1000 + 1000);

		k_sleep(RUN_LED_BLINK_INTERVAL);
	}
}

void ble_write_thread(void)
{
	/* Don't go any further until BLE is initailized */
	k_sem_take(&ble_init_ok, K_FOREVER);

	for (;;) {
		/* Wait indefinitely for data to be sent over bluetooth */
		char* buf = k_fifo_get(&fifo_ble_tx_data,
                                                     K_FOREVER);
                char test[10]; 
                sprintf(test, "%d", vcc);

		if (bt_gatt_nus_send(NULL, test, 5)) {
			printk("Failed to send data over BLE connection\n");
		}
		k_free(buf);
	}
}

void pwm_thread(void)
{
	struct device *pwm_dev;
	u32_t pulse_width = 0U;
	u8_t dir = 0U;

	printk("PWM demo app-fade LED\n");

	pwm_dev = device_get_binding(PWM_DRIVER);
	if (!pwm_dev) {
		printk("Cannot find %s!\n", PWM_DRIVER);
		return;
	}

	while (1) {
		if (pwm_pin_set_usec(pwm_dev, PWM_CHANNEL,
					PERIOD, pulse_width)) {
			printk("pwm pin set fails\n");
			return;
		}
                

		if (dir) {
			if (pulse_width < FADESTEP) {
				dir = 0U;
				pulse_width = 0U;
			} else {
				pulse_width -= FADESTEP * (led_blink_state+1);
			}
		} else {
			pulse_width += FADESTEP * (led_blink_state+1);

			if (pulse_width >= PERIOD) {
				dir = 1U;
				pulse_width = PERIOD;
			}
		}
                
		k_sleep(50);
	}
}

void bitbang_pwm_thread()
{
  
  const int period = 20000;
  while(1)
  {
    if (pulse_width < 1500)
    {
      set_led_state(SERVO_OUT, 1);
      k_busy_wait(pulse_width);
      set_led_state(SERVO_OUT, 0);
    }
    k_sleep(20);
  }
}




uint16_t pwm_seq[4] = {30000, 30000, 15000, 15000};
void setup_pwm()
{


    NRF_PWM0->COUNTERTOP = 20000 << PWM_COUNTERTOP_COUNTERTOP_Pos;
    NRF_PWM0->PSEL.OUT[0] = 23;
    NRF_PWM0->ENABLE = 1;
    NRF_PWM0->PRESCALER   = (PWM_PRESCALER_PRESCALER_DIV_16 << PWM_PRESCALER_PRESCALER_Pos);
    NRF_PWM0->DECODER = (PWM_DECODER_LOAD_Individual << PWM_DECODER_LOAD_Pos) |
        (PWM_DECODER_MODE_RefreshCount << PWM_DECODER_MODE_Pos);
    NRF_PWM0->SEQ[0].PTR = (uint32_t)pwm_seq << PWM_SEQ_PTR_PTR_Pos;
    NRF_PWM0->SEQ[0].CNT = (sizeof(pwm_seq)/sizeof(uint16_t)) << PWM_SEQ_CNT_CNT_Pos;
    NRF_PWM0->SEQ[0].REFRESH = 0;
    NRF_PWM0->SEQ[0].ENDDELAY = 0;
    NRF_PWM0->TASKS_SEQSTART[0] = 1;

}


char random_char()
{
  NRF_RNG->TASKS_START = 1;
  NRF_RNG->SHORTS = RNG_SHORTS_VALRDY_STOP_Enabled;
  while (!NRF_RNG->EVENTS_VALRDY);
  return  (char)NRF_RNG->VALUE;
}



void set_pwm_value(uint16_t value)
{
    for(int i = 0; i < 4; i++)
    {
        pwm_seq[0] = NRF_PWM0->COUNTERTOP - value;
    }
    NRF_PWM0->TASKS_SEQSTART[0] = 1;
}

void manual_pwm_thread()
{
  while(1)
  {
    set_pwm_value(pulse_width);
    k_sleep(500);
  }
}

void main()
{
  //setup_adc();
  setup_pwm();
  //volatile int adc_result = sample_adc();
  //volatile int adc_result2 = sample_adc();
  k_sleep(100);


  volatile int vcc2 = sample_adc();

}

K_THREAD_DEFINE(led_blink_thread_id, STACKSIZE, led_blink_thread, NULL, NULL,
		NULL, PRIORITY, 0, K_NO_WAIT);

K_THREAD_DEFINE(ble_write_thread_id, STACKSIZE, ble_write_thread, NULL, NULL,
		NULL, PRIORITY, 0, K_NO_WAIT);

//K_THREAD_DEFINE(pwm_thread_id, STACKSIZE/2, pwm_thread, NULL, NULL,
//		NULL, PRIORITY, 0, K_NO_WAIT);

//K_THREAD_DEFINE(bb_pwm_thread_id, STACKSIZE/8, bitbang_pwm_thread, NULL, NULL,
//		NULL, PRIORITY, 0, K_NO_WAIT);
K_THREAD_DEFINE(man_pwm_thread_id, STACKSIZE/8, manual_pwm_thread, NULL, NULL,
		NULL, PRIORITY, 0, K_NO_WAIT);