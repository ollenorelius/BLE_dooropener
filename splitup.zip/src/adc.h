#ifndef __ADC__
#define  __ADC__

int sample_adc();

#endif